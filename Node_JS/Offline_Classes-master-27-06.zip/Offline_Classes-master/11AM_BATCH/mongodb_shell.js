Shell Operations 
----------------
database -> showroom
table -> 			employee
rows -> 				some data 

CREATE Operations
-----------------
db.employee.insertOne({name : 'John' , age  : 40 , designation : 'Manager'});
db.employee.insertOne({name : 'Wilson' , age  : 45 , designation : 'Sr.Manager'});

db.employee.insertMany([
{
	name : 'Rajan',
	age : 25,
	designation : 'Software Engineer'
},
{
	name : 'Laura',
	age : 22,
	designation : 'Associate SoftwareEngineer'
}
]);

READ Operations
---------------
select * from employee; // Oracle
db.employee.find(); // Mongo DB

Select * from employee where name = 'John';
db.employee.find({name: 'John'});

Select * from employee where age > 35;
db.employee.find({ age : { $gt: 35 } });

UPDATE Opearations
------------------
UPDATE Employee
SET designation = 'Project Manager'
WHERE name = 'John';

db.employee.updateOne(
      { "name" : "John" },
      { $set: { "designation" : 'Project Manager' } }
   );
   
db.employee.updateOne(
      { "name" : "John" },
      { $set: { "age" : '42' } }
   );

DELETE Operations
-----------------
DELETE * from employee where name = 'John';

db.employee.deleteOne( { "name" : 'John' } );





