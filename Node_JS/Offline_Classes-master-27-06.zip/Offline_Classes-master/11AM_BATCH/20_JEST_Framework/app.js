function sum(a, b) {
    return a + b;
}

let greet = (name) => {
    return  `Good Morning ${name}`;
};

module.exports = {
    sum,
    greet
};