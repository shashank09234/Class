// External JQuery
$('#red-btn').click(function() {
    $('#red-card').toggle(1000);
});